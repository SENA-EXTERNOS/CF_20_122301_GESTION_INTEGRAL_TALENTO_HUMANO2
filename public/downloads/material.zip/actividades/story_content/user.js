function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6HFKYonh8Hq":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

